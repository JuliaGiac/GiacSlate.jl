# laplace_lesson — local inspection

This directory contains untrusted notebook code. Verify the files before opening them.
Installing the environment may execute package build scripts; opening the notebook in live mode
may execute arbitrary code.

Verify the downloaded files:

```sh
sha256sum -c SHA256SUMS
```

Inspect without starting a worker or executing cells:

```julia
using KaimonSlate
KaimonSlate.serve_notebook("laplace_lesson.jl"; inactive = true)
```

## 1. Isolated container (recommended)

This keeps package installation and notebook inspection out of the host. The image opens the
notebook in inactive mode; it does not evaluate cells:

```sh
podman build -t laplace_lesson-inspect .
podman run --rm -it -p 8765:8765 laplace_lesson-inspect
```

Alternatively, open `devcontainer.json` in a compatible editor.

## 2. Pinned host environment

This uses the published project and manifest, but runs package build scripts and notebook code
with your host account's permissions:

```sh
julia --project=. -e 'using Pkg; Pkg.instantiate()'
julia --project=. -e 'using KaimonSlate; KaimonSlate.serve_notebook("laplace_lesson.jl")'
```

## 3. Native application

Installing and opening the application executes code with your host account's permissions:

```sh
julia -e 'using Pkg; Pkg.Registry.add(Pkg.Registry.RegistrySpec(url="https://github.com/kahliburke/SlateRegistry")); Pkg.Apps.add("KaimonSlate")'
slate --own laplace_lesson.jl
```
